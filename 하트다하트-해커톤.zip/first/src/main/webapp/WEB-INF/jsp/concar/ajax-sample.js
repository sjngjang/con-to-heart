// Load the Visualization API and the piechart package.


google.load('visualization', '1', {'packages':['corechart']});

// Set a callback to run when the Google Visualization API is loaded.

google.setOnLoadCallback(drawChart);

function drawChart(){
	var jasonData = $.ajax({
		url: "sampleData.json",
		dataType:"jason",
		async: false
	}).responseText;
	
	//Create our data table out of JASON data loaded from server.
	
	var data = new google.visualization.DataTable(jasonData);
	
	//Instatiate and draw our chart, passing in some options.
	
	var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
	
	chart.draw(data, {width: 400, height: 240});
}